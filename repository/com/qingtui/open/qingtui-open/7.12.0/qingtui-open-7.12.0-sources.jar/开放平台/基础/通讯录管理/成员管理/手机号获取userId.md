通过手机号获取其所对应的userId。

**请求方式：** GET
**请求地址：** https://open.qingtui.com/team/user/userid/list?access_token=ACCESS_TOKEN&mobileList=手机号1&mobileList=手机号2

#### 请求参数

| 名称         | 类型           | 描述             |
|------------|--------------|----------------|
| mobileList | List(String) | 用户在轻推通讯录中的手机号码 |

#### 返回参数

| 名称                                 | 类型           | 描述           |
|------------------------------------|--------------|--------------|
| code                               | Int          | 错误码，非 0 表示失败 |
| message                            | String       | 错误描述         |
| data                               | Object       | -            |
| <p style="text-indent:20px">list   | List(Object) | 成员列表         |
| <p style="text-indent:40px">mobile | String       | 电话           |
| <p style="text-indent:40px">userId | String       | UserId       |

#### 返回示例

```
{
	"code": 0,
	"message": ""
	"data": {
	"list": [{
	    "mobile":"电话",
	    "userId":"userId"
	}]
}
```