> 为了安全考虑，开发者 请勿 将 access_token 返回给前端，需要开发者保存在后台，所有访问企业微信api的请求由后台发起

获取access_token是调用企业微信API接口的第一步，相当于创建了一个登录凭证，其它的业务API接口，都需要依赖于access_token来鉴权调用者身份。

因此开发者，在使用业务接口前，要明确access_token的颁发来源，使用正确的access_token。

### 请求

HTTP 请求地址

```
GET https://open.qingtui.com/v2/token
```

SDK 调用

```
tokenService.getToken()
```

#### 请求参数

| 名称        | 类型     | 必填 | 描述   |
|-----------|--------|----|------|
| appId     | string | 是  | 应用id |
| appSecret | string | 是  | 应用密钥 |

**权限说明：**

每个应用有独立的appSecret，获取到的access_token只能本应用使用，所以每个应用的access_token应该分开来获取

#### 请求体示例

```
{
    "appId": "应用id",
    "appSecret": "应用密钥"
}
```

## 响应

#### 响应体

| 名称                                      | 类型     | 描述              |
|-----------------------------------------|--------|-----------------|
| code                                    | Int    | 错误码，非 0 表示失败    |
| message                                 | String | 错误描述            |
| data                                    | Object | -               |
| <p style="text-indent:20px">accessToken | String | 获取到的凭证，最长为512字节 |
| <p style="text-indent:20px">expiresIn   | String | 凭证的有效时间（秒）      |

#### 响应体示例

```
{
    "code": 0,
    "message": "",
    "data": {
        "accessToken": "请求token",
        "expiresIn": 7200
    }
}
```
