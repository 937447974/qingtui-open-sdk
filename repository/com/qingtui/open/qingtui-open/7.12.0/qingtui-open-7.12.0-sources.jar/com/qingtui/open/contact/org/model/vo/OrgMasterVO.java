package com.qingtui.open.contact.org.model.vo;

import java.io.Serializable;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

/**
 * <p> title: 组织机构负责人
 * <p> time: 2022/3/2 10:05 AM
 * <p> Copyright © 2010-2022 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ToString
@NoArgsConstructor
@Accessors(chain = true)
public class OrgMasterVO implements Serializable {
    /**
     * 组织机构id
     */
    String orgId;
    /**
     * 账号id
     */
    String accountId;
    /**
     * 姓名
     */
    String name;

}
