package com.qingtui.open.im.message.model.dto;

import lombok.*;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p> title:
 * <p> time: 2025/5/8 13:47
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class MessageTextDTO implements Serializable {
    /**
     * 发送的文本消息内容
     */
    String content;
}
