package com.qingtui.open.schedule.model.param;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

/**
 * <p> title:
 * <p> time: 2024/5/10 10:59
 * <p> Copyright © 2010-2024 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ToString
@NoArgsConstructor
public class ScheduleListParam implements Serializable {
    Integer pageSize;
    String lastId;
    Long gmtStart;
    Long gmtEnd;
    List<String> mobilePhoneList;
    List<String> workIdList;
}
