package com.qingtui.open.schedule.model.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

/**
 * <p> title: 日程详情
 * <p> time: 2024/5/10 10:28
 * <p> Copyright © 2010-2024 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@NoArgsConstructor
public class ScheduleInfo extends ScheduleIdInfo {

    /**
     * 主题
     */
    String topic;
    /**
     * 是否全天
     */
    Boolean wholeDayEvent;
    /**
     * 开始时间
     */
    Long gmtStart;
    /**
     * 结束时间
     */
    Long gmtEnd;
    /**
     * 提醒类型 不提醒：0，提前5分钟：1，提前15分钟：2，提前30分钟：3，提前1小时：4，提前一天：5
     */
    Integer remindType;
    /**
     * 重复类型 不重复：0，每工作日：1，每日：2，每周：3，每两周：4，每月：5
     */
    Integer repeatType;

    /**
     * 创建人电话号码
     */
    String creatorMobilePhone;
    /**
     * 创建人电话号码
     */
    String creatorWorkId;
    /**
     * 协作人列表
     */
    List<SchedulePartnerInfo> cooperationUserList;
}
