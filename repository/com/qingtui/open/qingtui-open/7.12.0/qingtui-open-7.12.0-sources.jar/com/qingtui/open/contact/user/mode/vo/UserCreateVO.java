package com.qingtui.open.contact.user.mode.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p> title:
 * <p> time: 2025/3/11 17:15
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Accessors(chain = true)
@Data
@EqualsAndHashCode
@NoArgsConstructor
@ToString
public class UserCreateVO implements Serializable {
    String userId;
}
