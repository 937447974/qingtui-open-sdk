package com.qingtui.open.schedule.model.vo;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * <p> title:
 * <p> time: 2024/5/10 11:23
 * <p> Copyright © 2010-2024 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ToString
@NoArgsConstructor
public class ScheduleIdInfo implements Serializable {

    String scheduleId;
}
