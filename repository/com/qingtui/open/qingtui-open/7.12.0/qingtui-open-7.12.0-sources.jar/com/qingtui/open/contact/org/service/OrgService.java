package com.qingtui.open.contact.org.service;

import com.qingtui.open.base.model.param.ListParam;
import com.qingtui.open.contact.org.model.param.OrgMasterListParam;
import com.qingtui.open.contact.org.model.param.OrgMasterUpdateParam;
import com.qingtui.open.contact.org.model.param.OrgMemberPositionParam;
import com.qingtui.open.contact.org.model.vo.OrgMasterVO;

import java.util.List;

/**
 * <p> title: 组织机构业务接口
 * <p> time: 2022/3/1 6:13 PM
 * <p> Copyright © 2010-2022 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public interface OrgService {

    /**
     * 修改部门负责人
     *
     * @param param ListParam<OrgMasterUpdateParam>
     */
    void updateMaster(ListParam<OrgMasterUpdateParam> param);

    /**
     * 获取部门负责人
     *
     * @param param OrgMasterListParam
     * @return List\<OrgMasterVO>
     */
    List<OrgMasterVO> listMaster(OrgMasterListParam param);

    /**
     * 更新组织中成员位置
     *
     * @param param 更新用户的请求
     */
    void updateMemberPosition(ListParam<OrgMemberPositionParam> param);

}
