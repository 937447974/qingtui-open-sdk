package com.qingtui.open.app.service;

import java.util.List;

/**
 * <p> title:
 * <p> time: 2025/5/8 13:36
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public interface AppService {

    /**
     * @return 使用者的openid列表
     */
    List<String> listFollower();

}
