package com.qingtui.open.contact.org.model.param;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * <p> title: 更新用户位置
 * <p> time: 2024/2/20 10:34
 * <p> Copyright © 2010-2024 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ToString
@NoArgsConstructor
@Accessors(chain = true)
public class OrgMemberPositionParam implements Serializable {
    @NotNull
    String userId;
    @NotNull
    String orgId;
    @NotNull
    Long position;
}
