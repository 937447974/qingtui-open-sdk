package com.qingtui.open.schedule.model.param;

import com.qingtui.open.schedule.model.vo.ScheduleIdInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * <p> title: 完成日程
 * <p> time: 2024/5/10 10:53
 * <p> Copyright © 2010-2024 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@NoArgsConstructor
public class ScheduleCompleteParam extends ScheduleIdInfo {
    /**
     * 完成日程的电话号码
     */
    String mobilePhone;
}
