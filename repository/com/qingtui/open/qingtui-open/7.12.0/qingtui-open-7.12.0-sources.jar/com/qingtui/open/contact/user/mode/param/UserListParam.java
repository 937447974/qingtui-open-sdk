package com.qingtui.open.contact.user.mode.param;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.io.Serializable;

/**
 * <p> title: 成员列表获取
 * <p> time: 2024/5/10 10:59
 * <p> Copyright © 2010-2024 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@EqualsAndHashCode
@NoArgsConstructor
@ToString
public class UserListParam implements Serializable {
    @Min(value = 1, message = "{page.min}")
    Integer page = 1;
    @Min(value = 1, message = "{size.min}")
    @Max(value = 1000, message = "{size.max}")
    Integer size = 1000;
    /**
     * 组织机构id
     */
    String organizationId = null;
    /**
     * 是否需要组织机构列表
     */
    Boolean needOrganization = false;
    /**
     * 是否需要扩展字段列表
     */
    Boolean needExtendField = false;
}
