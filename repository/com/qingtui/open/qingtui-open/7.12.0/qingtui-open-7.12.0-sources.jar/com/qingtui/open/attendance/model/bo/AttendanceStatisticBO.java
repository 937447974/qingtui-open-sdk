package com.qingtui.open.attendance.model.bo;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * <p> title:
 * <p> time: 2025/7/2 17:41
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ToString
@NoArgsConstructor
public class AttendanceStatisticBO {
    /**
     * 员工id
     */
    String userId;
    /**
     * 统计时间(当日0点)
     */
    Long gmtStatistic;
    /**
     * 最终状态 正常1 迟到2 早退3 缺勤4 缺上班卡5 缺下班卡6 迟到并早退7 迟到并缺下班卡8
     */
    Integer status;
    /**
     * 异常打卡的原因
     */
    String anomaly;
    /**
     * 管理员备注
     */
    String adminComment;
    /**
     * 上班打卡时间
     */
    Long gmtSignIn;
    /**
     * 上班打卡地点
     */
    String signInAddress;
    /**
     * 修改上班打卡结果的原因
     */
    String signInReason;
    /**
     * 下班打卡时间
     */
    Long gmtSignOut;
    /**
     * 下班打卡时间
     */
    String signOutAddress;
    /**
     * 修改下班打卡结果的原因
     */
    String signOutReason;

}
