package com.qingtui.open.subscription.model.vo;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * <p> title:
 * <p> time: 2023/10/25 10:34
 * <p> Copyright © 2010-2023 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ToString
@NoArgsConstructor
public class SubscriptionArticleInfo implements Serializable {
    String id;
    String title;
    String url;
    Long gmtCreate;
}
