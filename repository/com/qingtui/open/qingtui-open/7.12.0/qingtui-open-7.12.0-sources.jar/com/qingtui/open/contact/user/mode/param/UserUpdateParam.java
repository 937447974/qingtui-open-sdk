package com.qingtui.open.contact.user.mode.param;

import com.qingtui.open.contact.user.mode.dto.UserExtendFieldDTO;
import com.qingtui.open.contact.user.mode.dto.UserOrganizationDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * <p> title: 修改成员
 * <p> time: 2024/2/21 09:49
 * <p> Copyright © 2010-2024 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Accessors(chain = true)
@Data
@EqualsAndHashCode
@NoArgsConstructor
@ToString
public class UserUpdateParam implements Serializable {

    @NotNull
    String userId;
    /**
     * 姓名
     */
    @NotNull
    String name;
    /**
     * 邮箱
     */
    String email;
    /**
     * 工号
     */
    String jobNumber;
    /**
     * 个人描述
     */
    String comment;
    /**
     * 组织机构list
     */
    List<UserOrganizationDTO> organizationList;
    /**
     * 用户扩展字段
     */
    List<UserExtendFieldDTO> extendFieldList;

}