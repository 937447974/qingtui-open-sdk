package com.qingtui.open.contact.user.mode.bo;

import com.qingtui.open.contact.user.mode.dto.UserExtendFieldDTO;
import com.qingtui.open.contact.user.mode.dto.UserOrganizationDTO;
import com.qingtui.open.contact.user.mode.param.UserUpdateParam;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * <p> title: 成员详情
 * <p> time: 2024/2/21 10:05
 * <p> Copyright © 2010-2024 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@Accessors(chain = true)
public class UserBO implements Serializable {

    String userId;

    // 员工个人信息
    /**
     * +86 国家编码
     */
    String countryCode;
    /**
     * 电话
     */
    String mobile;
    /**
     * 头像
     */
    String avatar;

    // 员工企业信息
    /**
     * 姓名
     */
    String name;
    /**
     * 邮箱
     */
    String email;
    /**
     * 工号
     */
    String jobNumber;
    /**
     * 个人描述
     */
    String comment;
    /**
     * 组织机构list
     */
    List<UserOrganizationDTO> organizationList;
    /**
     * 用户扩展字段
     */
    List<UserExtendFieldDTO> extendFieldList;
}
