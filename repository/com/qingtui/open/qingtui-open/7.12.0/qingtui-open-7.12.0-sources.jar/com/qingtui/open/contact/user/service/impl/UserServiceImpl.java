package com.qingtui.open.contact.user.service.impl;

import com.alibaba.fastjson.TypeReference;
import com.qingtui.open.base.http.HttpClient;
import com.qingtui.open.base.model.bo.ListBO;
import com.qingtui.open.base.service.BaseService;
import com.qingtui.open.contact.user.mode.bo.UserBO;
import com.qingtui.open.contact.user.mode.bo.UserIdBO;
import com.qingtui.open.contact.user.mode.param.*;
import com.qingtui.open.contact.user.mode.vo.UserCreateVO;
import com.qingtui.open.contact.user.service.UserService;
import com.qingtui.open.token.service.TokenService;
import lombok.val;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static com.qingtui.open.contact.user.mode.constant.UrlConstants.*;

/**
 * <p> title: 成员管理
 * <p> time: 2024/2/20 18:17
 * <p> Copyright © 2010-2024 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public class UserServiceImpl extends BaseService implements UserService {

    public UserServiceImpl(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    /**
     * 增加成员,返回员工id
     */
    @Override
    public String createUser(UserCreateParam param) {
        val vo = HttpClient.postRequest(getTeamUrl(USER), param).data(new TypeReference<UserCreateVO>() {
        });
        return vo == null ? null : vo.getUserId();
    }

    /**
     * 删除成员
     */
    @Override
    public void deleteUser(String userId) {
        val param = new UserDeleteParam();
        param.setUserId(userId);
        HttpClient.deleteRequest(getTeamUrl(USER), param);
    }

    /**
     * 更新成员
     */
    @Override
    public void updateUser(UserUpdateParam param) {
        HttpClient.putRequest(getTeamUrl(USER), param);
    }

    /**
     * 获取成员
     */
    @Override
    public UserBO getUser(String userId) {
        val param = new HashMap<>();
        param.put("userId", userId);
        return HttpClient.getRequest(getTeamUrl(USER), param).data(new TypeReference<UserBO>() {
        });
    }

    /**
     * 获取成员
     */
    @Override
    public List<UserBO> listUser(UserListParam param) {
        return HttpClient.getRequest(getTeamUrl(USER_LIST), param).list(new TypeReference<ListBO<UserBO>>() {
        });
    }

    /**
     * 通过手机号获取其所对应的userId
     */
    @Override
    public String getUserIdByMobile(String mobile) {
        val list = listUserIdByMobile(Collections.singletonList(mobile));
        return list.isEmpty() ? null : list.get(0).getUserId();
    }

    /**
     * 通过手机号批量获取其所对应的userId
     */
    @Override
    public List<UserIdBO> listUserIdByMobile(List<String> mobileList) {
        val param = new UserIdListParam();
        param.setMobileList(mobileList);
        return HttpClient.getRequest(getTeamUrl(USER_USERID_LIST), param).list(new TypeReference<ListBO<UserIdBO>>() {
        });
    }

}
