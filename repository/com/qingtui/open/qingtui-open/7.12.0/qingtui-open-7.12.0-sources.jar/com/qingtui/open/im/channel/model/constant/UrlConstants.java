package com.qingtui.open.im.channel.model.constant;

/**
 * <p> title: 路径常量
 * <p> time: 2025/4/7 15:53
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public class UrlConstants {

    public static final String CHAT_CHANNEL = "/chat/channel";

}