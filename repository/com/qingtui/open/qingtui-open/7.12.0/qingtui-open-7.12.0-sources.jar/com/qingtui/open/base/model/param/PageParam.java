package com.qingtui.open.base.model.param;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.experimental.Accessors;

/**
 * <p> title: 分页请求
 * <p> time: 2025/7/2 17:34
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class PageParam {

    /**
     * 请求页数，默认1开始
     */
    @NonNull
    Integer page = 1;
    /**
     * 每页个数，默认20
     */
    @NonNull
    Integer size = 20;

}
