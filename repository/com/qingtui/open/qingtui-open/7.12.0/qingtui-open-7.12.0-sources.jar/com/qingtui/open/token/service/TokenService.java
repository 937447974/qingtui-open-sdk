package com.qingtui.open.token.service;

import com.qingtui.open.token.model.bo.TokenBO;

/**
 * <p> title:
 * <p> time: 2025/4/15 15:11
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public interface TokenService {

    /**
     * 刷新 Token,建议每个小时调用一次
     */
    void refreshToken();

    //======= 下列方法供框架使用

    String getTeamUrl(String path);

    String getBaseUrl(String path);

}
