package com.qingtui.open.attendance.service;

import com.qingtui.open.attendance.model.bo.AttendanceStatisticBO;

import java.util.List;

/**
 * <p> title:
 * <p> time: 2025/7/2 17:33
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public interface AttendanceService {
    /**
     * 获取考勤统计记录
     *
     * @param gmtStatistic 统计时间(当日0点)
     * @return List(AttendanceStatisticBO)
     */
    List<AttendanceStatisticBO> listAttendanceStatistic(Long gmtStatistic);
}
