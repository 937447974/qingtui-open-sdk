package com.qingtui.open.im.channel.service.impl;

import com.alibaba.fastjson.TypeReference;
import com.qingtui.open.base.http.HttpClient;
import com.qingtui.open.base.service.BaseService;
import com.qingtui.open.im.channel.model.bo.ChannelBO;
import com.qingtui.open.im.channel.model.bo.ChannelIdBO;
import com.qingtui.open.im.channel.model.param.ChannelCreateParam;
import com.qingtui.open.im.channel.model.param.ChannelUpdateParam;
import com.qingtui.open.im.channel.service.ChannelService;
import com.qingtui.open.token.service.TokenService;
import lombok.val;

import static com.qingtui.open.im.channel.model.constant.UrlConstants.CHAT_CHANNEL;

/**
 * <p> title:
 * <p> time: 2025/4/15 14:25
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public class ChannelServiceImpl extends BaseService implements ChannelService {

    public ChannelServiceImpl(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    /**
     * 增加群
     *
     * @return 群id
     */
    @Override
    public String createChannel(ChannelCreateParam param) {
        val vo = HttpClient.postRequest(getTeamUrl(CHAT_CHANNEL), param).data(new TypeReference<ChannelIdBO>() {
        });
        return vo == null ? null : vo.getChannelId();
    }

    /**
     * 更新群聊会话
     */
    @Override
    public void updateChannel(ChannelUpdateParam param) {
        HttpClient.putRequest(getTeamUrl(CHAT_CHANNEL), param);
    }

    /**
     * 获取群聊
     */
    @Override
    public ChannelBO getChannel(String channelId) {
        val param = new ChannelIdBO();
        param.setChannelId(channelId);
        return HttpClient.getRequest(getTeamUrl(CHAT_CHANNEL), param).data(new TypeReference<ChannelBO>() {
        });
    }
}
