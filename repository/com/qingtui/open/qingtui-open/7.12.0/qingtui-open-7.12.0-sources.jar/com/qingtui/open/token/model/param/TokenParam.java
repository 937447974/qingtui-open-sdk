package com.qingtui.open.token.model.param;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

/**
 * <p> title:
 * <p> time: 2025/4/15 16:25
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Accessors(chain = true)
@Data
@EqualsAndHashCode
@NoArgsConstructor
@ToString
public class TokenParam {
    /**
     * 应用id
     */
    String appId;
    /**
     * 应用密钥
     */
    String appSecret;
}
