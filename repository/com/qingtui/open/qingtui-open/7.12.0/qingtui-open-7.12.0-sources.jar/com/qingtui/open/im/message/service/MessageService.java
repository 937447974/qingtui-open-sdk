package com.qingtui.open.im.message.service;

/**
 * <p> title:
 * <p> time: 2025/5/8 13:48
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public interface MessageService {

    /**
     * 群发（轻应用/订阅号的所有关注者）文本消息
     */
    void sendText(String content);

}
