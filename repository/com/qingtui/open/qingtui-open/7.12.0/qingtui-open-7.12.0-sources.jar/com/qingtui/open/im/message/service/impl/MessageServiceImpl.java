package com.qingtui.open.im.message.service.impl;

import com.qingtui.open.base.http.HttpClient;
import com.qingtui.open.base.service.BaseService;
import com.qingtui.open.im.message.model.dto.MessageTextDTO;
import com.qingtui.open.im.message.model.param.MessageTextParam;
import com.qingtui.open.im.message.service.MessageService;
import com.qingtui.open.token.service.TokenService;
import lombok.val;

import static com.qingtui.open.im.message.model.constant.UrlConstants.MESSAGE_TEXT_SERVICE;

/**
 * <p> title: 消息服务
 * <p> time: 2025/5/8 13:48
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public class MessageServiceImpl extends BaseService implements MessageService {

    public MessageServiceImpl(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    @Override
    public void sendText(String content) {
        val message = new MessageTextDTO(content);
        val param = new MessageTextParam(message);
        HttpClient.postRequest(this.getBaseUrl(MESSAGE_TEXT_SERVICE), param);
    }

}
