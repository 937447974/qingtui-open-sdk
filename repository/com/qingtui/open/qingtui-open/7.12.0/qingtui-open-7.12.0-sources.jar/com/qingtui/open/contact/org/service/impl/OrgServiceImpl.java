package com.qingtui.open.contact.org.service.impl;

import com.alibaba.fastjson.TypeReference;
import com.qingtui.open.base.common.utils.CollectionUtils;
import com.qingtui.open.base.http.HttpClient;
import com.qingtui.open.base.model.param.ListParam;
import com.qingtui.open.base.model.bo.ListBO;
import com.qingtui.open.base.service.BaseService;
import com.qingtui.open.contact.org.model.param.OrgMasterListParam;
import com.qingtui.open.contact.org.model.param.OrgMasterUpdateParam;
import com.qingtui.open.contact.org.model.param.OrgMemberPositionParam;
import com.qingtui.open.contact.org.model.vo.OrgMasterVO;
import com.qingtui.open.contact.org.service.OrgService;
import com.qingtui.open.token.service.TokenService;

import java.util.ArrayList;
import java.util.List;

import static com.qingtui.open.contact.org.model.constant.UrlConstants.ORG_MASTER;
import static com.qingtui.open.contact.org.model.constant.UrlConstants.ORG_MEMBER_POSITION;

/**
 * <p> title: 组织机构业务接口
 * <p> time: 2022/3/1 6:13 PM
 * <p> Copyright © 2010-2022 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public class OrgServiceImpl extends BaseService implements OrgService {

    public OrgServiceImpl(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    /**
     * 修改部门负责人
     *
     * @param param ListParam<OrgMasterUpdateParam>
     */
    @Override
    public void updateMaster(ListParam<OrgMasterUpdateParam> param) {
        if (CollectionUtils.isEmpty(param.getList())) {
            return;
        }
        HttpClient.putRequest(getTeamUrl(ORG_MASTER), param);
    }

    /**
     * 获取部门负责人
     *
     * @param param OrgMasterListParam
     * @return List\<OrgMasterVO>
     */
    @Override
    public List<OrgMasterVO> listMaster(OrgMasterListParam param) {
        if (CollectionUtils.isEmpty(param.getOrgIdList())) {
            return new ArrayList<>();
        }
        return HttpClient.getRequest(getTeamUrl(ORG_MASTER), param).list(new TypeReference<ListBO<OrgMasterVO>>() {
        });
    }

    /**
     * 更新组织中成员位置
     *
     * @param param 更新用户的请求
     */
    @Override
    public void updateMemberPosition(ListParam<OrgMemberPositionParam> param) {
        if (CollectionUtils.isEmpty(param.getList())) {
            return;
        }
        HttpClient.putRequest(getTeamUrl(ORG_MEMBER_POSITION), param);
    }

}
