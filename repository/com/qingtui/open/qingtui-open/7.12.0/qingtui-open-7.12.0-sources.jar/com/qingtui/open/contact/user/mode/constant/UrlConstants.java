package com.qingtui.open.contact.user.mode.constant;

/**
 * <p> title: 路径常量
 * <p> time: 2021/4/20 11:28 上午
 * <p> Copyright © 2010-2021 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public class UrlConstants {

    public static final String USER = "/user";
    public static final String USER_LIST = "/user/list";
    public static final String USER_USERID_LIST = "/user/userid/list";

}