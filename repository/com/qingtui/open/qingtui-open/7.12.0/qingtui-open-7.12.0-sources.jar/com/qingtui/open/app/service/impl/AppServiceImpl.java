package com.qingtui.open.app.service.impl;

import com.alibaba.fastjson.TypeReference;
import com.qingtui.open.app.service.AppService;
import com.qingtui.open.base.http.HttpClient;
import com.qingtui.open.base.service.BaseService;
import com.qingtui.open.im.channel.model.bo.ChannelBO;
import com.qingtui.open.im.channel.model.bo.ChannelIdBO;
import com.qingtui.open.token.service.TokenService;
import lombok.val;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static com.qingtui.open.app.model.constant.UrlConstants.LIST_FOLLOWER;
import static com.qingtui.open.im.channel.model.constant.UrlConstants.CHAT_CHANNEL;

/**
 * <p> title:
 * <p> time: 2025/5/8 13:36
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public class AppServiceImpl extends BaseService implements AppService {

    public AppServiceImpl(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    @Override
    public List<String> listFollower() {
        val param = new HashMap<>();
        param.put("request_page", 1);
        param.put("page_size", 1000);
        val response = HttpClient.getRequest(getTeamUrl(LIST_FOLLOWER), param);
        return (List<String>) response.getBaseVO().getData().getJSONObject("followers");
    }
}
