package com.qingtui.open.contact.user.service;

import com.qingtui.open.contact.user.mode.bo.UserIdBO;
import com.qingtui.open.contact.user.mode.param.*;
import com.qingtui.open.contact.user.mode.bo.UserBO;

import java.util.List;

/**
 * <p> title: 成员管理
 * <p> time: 2024/2/20 18:17
 * <p> Copyright © 2010-2024 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public interface UserService {

    /**
     * 增加成员,返回员工id
     */
    String createUser(UserCreateParam param);

    /**
     * 删除成员
     */
    void deleteUser(String userId);

    /**
     * 更新成员
     */
    void updateUser(UserUpdateParam param);

    /**
     * 获取成员
     */
    UserBO getUser(String userId);

    /**
     * 获取成员列表
     */
    List<UserBO> listUser(UserListParam param);

    /**
     * 通过手机号获取其所对应的userId
     */
    String getUserIdByMobile(String mobile);

    /**
     * 通过手机号批量获取其所对应的userId
     */
    List<UserIdBO> listUserIdByMobile(List<String> mobileList);

}
