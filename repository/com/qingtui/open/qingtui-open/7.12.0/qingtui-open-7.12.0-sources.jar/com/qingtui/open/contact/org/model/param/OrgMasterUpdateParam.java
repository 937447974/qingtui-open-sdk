package com.qingtui.open.contact.org.model.param;

import java.io.Serializable;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;

/**
 * <p> title:
 * <p> time: 2022/3/2 5:55 PM
 * <p> Copyright © 2010-2022 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ToString
@NoArgsConstructor
@Accessors(chain = true)
public class OrgMasterUpdateParam implements Serializable {
    /**
     * 组织机构id
     */
    @NotNull
    String orgId;
    /**
     * 账号id
     */
    @NotNull
    List<String> accountIdList;
}


