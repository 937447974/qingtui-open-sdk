package com.qingtui.open.schedule.service;

import com.qingtui.open.schedule.model.param.ScheduleCompleteParam;
import com.qingtui.open.schedule.model.param.ScheduleListParam;
import com.qingtui.open.schedule.model.param.ScheduleSaveParam;
import com.qingtui.open.schedule.model.vo.ScheduleIdInfo;
import com.qingtui.open.schedule.model.vo.ScheduleInfo;

import java.util.List;

/**
 * <p> title:
 * <p> time: 2024/5/10 10:48
 * <p> Copyright © 2010-2024 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public interface ScheduleService {

    /**
     * 创建日程
     */
    String createSingle(ScheduleSaveParam param);

    /**
     * 修改日程
     */
    void updateSingle(ScheduleSaveParam param);

    /**
     * 完成日程
     */
    void completeSingle(ScheduleCompleteParam param);

    /**
     * 删除日程
     */
    void deleteSingle(ScheduleIdInfo param);

    /**
     * 获取日程
     */
    List<ScheduleInfo> list(ScheduleListParam param);

}


