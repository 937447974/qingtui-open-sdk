package com.qingtui.open.schedule.service.impl;

import com.alibaba.fastjson.TypeReference;
import com.qingtui.open.base.http.HttpClient;
import com.qingtui.open.base.model.bo.ListBO;
import com.qingtui.open.base.service.BaseService;
import com.qingtui.open.schedule.model.constant.UrlConstant;
import com.qingtui.open.schedule.model.param.ScheduleCompleteParam;
import com.qingtui.open.schedule.model.param.ScheduleListParam;
import com.qingtui.open.schedule.model.param.ScheduleSaveParam;
import com.qingtui.open.schedule.model.vo.ScheduleIdInfo;
import com.qingtui.open.schedule.model.vo.ScheduleInfo;
import com.qingtui.open.schedule.service.ScheduleService;
import com.qingtui.open.token.service.TokenService;
import lombok.val;

import java.util.List;

/**
 * <p> title:
 * <p> time: 2024/5/10 10:48
 * <p> Copyright © 2010-2024 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public class ScheduleServiceImpl extends BaseService implements ScheduleService {

    public ScheduleServiceImpl(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    /**
     * 创建日程
     */
    @Override
    public String createSingle(ScheduleSaveParam param) {
        val result = HttpClient.postRequest(getTeamUrl(UrlConstant.CREATE_SINGLE), param).data(new TypeReference<ScheduleIdInfo>() {
        });
        return result.getScheduleId();
    }

    /**
     * 修改日程
     */
    @Override
    public void updateSingle(ScheduleSaveParam param) {
        HttpClient.putRequest(getTeamUrl(UrlConstant.UPDATE_SINGLE), param);
    }

    /**
     * 完成日程
     */
    @Override
    public void completeSingle(ScheduleCompleteParam param) {
        HttpClient.putRequest(getTeamUrl(UrlConstant.COMPLETE_SINGLE), param);
    }

    /**
     * 删除日程
     */
    @Override
    public void deleteSingle(ScheduleIdInfo param) {
        HttpClient.deleteRequest(getTeamUrl(UrlConstant.DELETE_SINGLE), param);
    }

    /**
     * 获取日程
     */
    @Override
    public List<ScheduleInfo> list(ScheduleListParam param) {
        return HttpClient.getRequest(getTeamUrl(UrlConstant.LIST), param).list(new TypeReference<ListBO<ScheduleInfo>>() {
        });
    }

}


