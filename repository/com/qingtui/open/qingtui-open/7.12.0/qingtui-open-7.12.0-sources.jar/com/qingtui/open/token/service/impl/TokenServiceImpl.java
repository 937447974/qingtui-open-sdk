package com.qingtui.open.token.service.impl;

import com.alibaba.fastjson.TypeReference;
import com.dtflys.forest.config.ForestConfiguration;
import com.qingtui.open.base.http.HttpClient;

import com.qingtui.open.token.model.bo.TokenBO;
import com.qingtui.open.token.model.param.TokenParam;
import com.qingtui.open.token.service.TokenService;
import lombok.extern.slf4j.Slf4j;
import lombok.val;

import java.util.HashMap;
import java.util.Map;

import static com.qingtui.open.token.model.constant.UrlConstant.TOKEN;

/**
 * <p> title:
 * <p> time: 2025/4/15 15:11
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Slf4j
public class TokenServiceImpl implements TokenService {

    /**
     * 应用id
     */
    String appId;
    /**
     * 应用密钥
     */
    String appSecret;
    /**
     * 开放平台地址
     */
    String url;
    /**
     * 请求的token
     */
    String accessToken;

    public TokenServiceImpl(String appId, String appSecret, String url) {
        log.info("设置开放平台参数 {}, {} ", appId, url);
        this.appId = appId;
        this.appSecret = appSecret;
        this.url = url;
        this.refreshToken();
    }

    @Override
    public void refreshToken() {
        val oldLogEnabled = HttpClient.logEnabled;
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("grant_type", "client_credential");
        param.put("appid", this.appId);
        param.put("secret", this.appSecret);
        try {
            HttpClient.logEnabled = false;
            val data = HttpClient.getRequest(getBaseUrl("/token"), param).data(new TypeReference<TokenBO>() {
            });
            this.accessToken = data.getAccess_token();
            log.info("刷新 accessToken {} {}", this.appId, this.accessToken);
        } catch (Exception e) {
            log.error("刷新 accessToken 重试 {}", this.appId, e);
            try {
                val data = HttpClient.getRequest(this.url + TOKEN, param).data(new TypeReference<TokenBO>() {
                });
                this.accessToken = data.getAccessToken();
                log.info("刷新 accessToken 重试成功 {} {}", this.appId, this.accessToken);
            } catch (Exception re) {
                log.error("刷新 accessToken 重试失败 {}", this.appId, re);
                throw re;
            }
        } finally {
            HttpClient.logEnabled = oldLogEnabled;
        }
    }

    @Override
    public String getTeamUrl(String path) {
        return this.url + "/team" + path + "?accessToken=" + this.accessToken;
    }

    @Override
    public String getBaseUrl(String path) {
        return this.url + "/v1" + path + "?accessToken=" + this.accessToken;
    }

}
