package com.qingtui.open.subscription.model.constant;

/**
 * <p> title:
 * <p> time: 2023/10/25 11:24
 * <p> Copyright © 2010-2023 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public class UrlConstant {
    static final String SUB_PATH = "/subscription";
    public static final String ARTICLE_LIST = SUB_PATH + "/article/list";
}
