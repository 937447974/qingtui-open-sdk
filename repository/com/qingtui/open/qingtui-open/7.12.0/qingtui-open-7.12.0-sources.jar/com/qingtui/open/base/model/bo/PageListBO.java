package com.qingtui.open.base.model.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * <p> title:
 * <p> time: 2025/7/2 17:38
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PageListBO<T> implements Serializable {

    /**
     * 总数
     */
    Long total;
    /**
     * 数组
     */
    List<T> list;
}
