package com.qingtui.open.attendance.service.impl;

import com.alibaba.fastjson.TypeReference;
import com.qingtui.open.attendance.model.bo.AttendanceStatisticBO;
import com.qingtui.open.attendance.service.AttendanceService;
import com.qingtui.open.base.http.HttpClient;
import com.qingtui.open.base.model.bo.ListBO;
import com.qingtui.open.base.service.BaseService;
import com.qingtui.open.contact.user.mode.bo.UserBO;
import com.qingtui.open.token.service.TokenService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.qingtui.open.attendance.model.constant.UrlConstant.STATISTIC_LIST;

/**
 * <p> title:
 * <p> time: 2025/7/2 17:33
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public class AttendanceServiceImpl extends BaseService implements AttendanceService {

    public AttendanceServiceImpl(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    @Override
    public List<AttendanceStatisticBO> listAttendanceStatistic(Long gmtStatistic) {
        Map<String, Object> map = new HashMap<>();
        map.put("gmtStatistic", gmtStatistic);
        return HttpClient.getRequest(getTeamUrl(STATISTIC_LIST), map).list(new TypeReference<ListBO<AttendanceStatisticBO>>() {
        });
    }

}
