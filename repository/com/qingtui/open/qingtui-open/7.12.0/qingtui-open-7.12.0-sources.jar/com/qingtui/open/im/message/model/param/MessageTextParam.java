package com.qingtui.open.im.message.model.param;

import com.qingtui.open.im.message.model.dto.MessageTextDTO;
import lombok.*;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p> title:
 * <p> time: 2025/5/8 13:46
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class MessageTextParam implements Serializable {
    MessageTextDTO message;
}
