package com.qingtui.open.contact.user.mode.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.math.BigInteger;

/**
 * <p> title: 员工部门信息
 * <p> time: 2025/3/6 09:10
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Accessors(chain = true)
@Data
@EqualsAndHashCode
@NoArgsConstructor
@ToString
public class UserOrganizationDTO {
    /**
     * 组织机构Id
     */
    String organizationId;
    /**
     * 排序,需要唯一
     */
    BigInteger sequnce;

    /**
     * 是否主组织机构
     */
    Boolean master;
    /**
     * 职务
     */
    String duty;
}
