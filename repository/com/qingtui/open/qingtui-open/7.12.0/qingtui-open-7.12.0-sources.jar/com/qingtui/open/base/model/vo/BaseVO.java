package com.qingtui.open.base.model.vo;

import com.alibaba.fastjson.JSONObject;
import java.io.Serializable;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p> title:
 * <p> time: 2022/3/1 6:36 PM
 * <p> Copyright © 2010-2022 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@NoArgsConstructor
public class BaseVO implements Serializable {
    /**
     * 返回编码
     */
    Integer code;
    /**
     * 返回信息
     */
    String message;
    /**
     * 返回数据json
     */
    JSONObject data;
}
