package com.qingtui.open.im.channel.model.param;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;

/**
 * <p> title:
 * <p> time: 2025/4/7 15:55
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@Accessors(chain = true)
public class ChannelCreateParam implements Serializable {
    @Size(min = 1, max = 30)
    String name;
    @Size(max = 500)
    String comment;
    @NotNull
    String owner;
    @Size(max = 2000)
    List<String> userList;
}
