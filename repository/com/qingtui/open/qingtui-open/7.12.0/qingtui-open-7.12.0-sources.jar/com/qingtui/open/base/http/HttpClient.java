package com.qingtui.open.base.http;

import com.alibaba.fastjson.JSONObject;
import com.dtflys.forest.Forest;
import com.dtflys.forest.config.ForestConfiguration;
import com.dtflys.forest.exceptions.ForestNetworkException;
import com.dtflys.forest.http.ForestRequest;
import com.dtflys.forest.utils.TypeReference;
import com.qingtui.open.base.model.exception.SdkException;
import com.qingtui.open.base.model.vo.BaseVO;
import lombok.extern.slf4j.Slf4j;
import lombok.val;

import java.util.UUID;

/**
 * <p> title:
 * <p> time: 2022/3/1 6:57 PM
 * <p> Copyright © 2010-2022 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Slf4j
public class HttpClient {

    public static boolean logEnabled = true;

    static {
        // 默认配置
        log.info("开放平台设置默认配置");
        ForestConfiguration.configuration()
                .setLogEnabled(false)
                .setConnectTimeout(60000)
                .setReadTimeout(60000);
    }

    /**
     * post 请求
     *
     * @param url    路径
     * @param object 参数
     * @return BaseVO
     */
    public static HttpResponse postRequest(String url, Object object) {
        val requestId = UUID.randomUUID().toString();
        if (logEnabled) {
            log.info("[{}] POST {} {}", requestId, url, object);
        }
        return execute(requestId, Forest.post(url).contentTypeJson().addBody(object));
    }

    /**
     * delete 请求
     *
     * @param url    路径
     * @param object 参数
     * @return BaseVO
     */
    public static HttpResponse deleteRequest(String url, Object object) {
        val requestId = UUID.randomUUID().toString();
        if (logEnabled) {
            log.info("[{}] DELETE {} {}", requestId, url, object);
        }
        return execute(requestId, Forest.delete(url).contentTypeJson().addBody(object));
    }

    /**
     * put 请求
     *
     * @param url    路径
     * @param object 参数
     * @return BaseVO
     */
    public static HttpResponse putRequest(String url, Object object) {
        val requestId = UUID.randomUUID().toString();
        if (logEnabled) {
            log.info("[{}] PUT {} {}", requestId, url, object);
        }
        return execute(requestId, Forest.put(url).contentTypeJson().addBody(object));
    }

    /**
     * get 请求
     *
     * @param url    路径
     * @param object 参数
     * @return BaseVO
     */
    public static HttpResponse getRequest(String url, Object object) {
        val requestId = UUID.randomUUID().toString();
        if (logEnabled) {
            log.info("[{}] GET {} {}", requestId, url, object);
        }
        return execute(requestId, Forest.get(url).addQuery(object));
    }

    private static HttpResponse execute(String requestId, ForestRequest<?> forestRequest) {
        try {
            val vo = forestRequest.execute(JSONObject.class);
            if (logEnabled) {
                log.info("[{}] Response Content: {}", requestId, vo);
            }
            return new HttpResponse(vo);
        } catch (ForestNetworkException e) {
            if (e.getStatusCode() == 500) {
                val baseVO = e.getResponse().get(new TypeReference<BaseVO>() {
                });
                if (baseVO != null && baseVO.getCode() != 0 && baseVO.getCode() != 200) {
                    throw new SdkException(baseVO);
                }
            }
            throw e;
        }
    }

}
