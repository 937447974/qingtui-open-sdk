package com.qingtui.open.base.model.exception;

import static com.qingtui.open.base.model.constant.ExceptionConstants.SYSTEM_ERROR_CODE;
import static com.qingtui.open.base.model.constant.ExceptionConstants.SYSTEM_ERROR_MESSAGE;

import com.qingtui.open.base.model.vo.BaseVO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

/**
 * <p> title: SDK异常，外部可捕获处理
 * <p> time: 2022/3/1 6:57 PM
 * <p> Copyright © 2010-2022 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@Slf4j
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class SdkException extends RuntimeException {

    long code = SYSTEM_ERROR_CODE;

    public SdkException() {
        super(SYSTEM_ERROR_MESSAGE);
    }

    public SdkException(BaseVO vo) {
        super(mergeErrorCodeAndMsg(vo.getCode(), vo.getMessage()));
        this.code = vo.getCode();
        log.error("轻推开放平台异常", this);
    }

    private static String mergeErrorCodeAndMsg(long code, String errorMsg) {
        return code + ": " + errorMsg;
    }

}
