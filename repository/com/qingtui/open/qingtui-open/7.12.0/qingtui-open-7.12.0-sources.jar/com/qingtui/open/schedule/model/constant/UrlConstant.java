package com.qingtui.open.schedule.model.constant;

/**
 * <p> title:
 * <p> time: 2023/10/25 11:24
 * <p> Copyright © 2010-2023 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public class UrlConstant {
    static final String SUB_PATH = "/schedule";
    public static final String CREATE_SINGLE = SUB_PATH + "/create/single";
    public static final String UPDATE_SINGLE = SUB_PATH + "/update/single";
    public static final String COMPLETE_SINGLE = SUB_PATH + "/complete/single";
    public static final String DELETE_SINGLE = SUB_PATH + "/delete/single";
    public static final String LIST = SUB_PATH + "/list";
}
