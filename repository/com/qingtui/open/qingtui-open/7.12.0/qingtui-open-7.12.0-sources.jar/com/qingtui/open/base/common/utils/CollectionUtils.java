package com.qingtui.open.base.common.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * <p> title: 集合工具
 * <p> time: 2021/4/1 3:17 下午
 *
 * @author 阳君
 * @version 1.0.0
 */
public class CollectionUtils {

    /**
     * 判断是否为空
     *
     * @param coll 集合
     * @return Boolean
     */
    public static Boolean isEmpty(Collection<?> coll) {
        return coll == null || coll.isEmpty();
    }

    /**
     * 判断是否不为空
     *
     * @param coll 集合
     * @return Boolean
     */
    public static Boolean isNotEmpty(Collection<?> coll) {
        return !isEmpty(coll);
    }

    /**
     * 判断map是否为空
     *
     * @param map 集合
     * @return Boolean
     */
    public static Boolean isEmpty(Map<?, ?> map) {
        return map == null || map.isEmpty();
    }

    /**
     * 判断map是否不为空
     *
     * @param map 集合
     * @return Boolean
     */
    public static Boolean isNotEmpty(Map<?, ?> map) {
        return !isEmpty(map);
    }

    /**
     * 数组提值
     *
     * @param list  数组
     * @param index 位置
     * @param <E>   泛型
     * @return E 可能为空
     */
    public static <E> E get(List<E> list, int index) {
        return isEmpty(list) ? null : list.get(index);
    }

    /**
     * 集合转数组
     *
     * @param coll   集合
     * @param mapper T-R转换器
     * @param <T>    输入泛型
     * @param <R>    输出泛型
     * @return List R
     */
    public static <T, R> List<R> toList(Collection<T> coll, Function<? super T, ? extends R> mapper) {
        if (isEmpty(coll)) {
            return new ArrayList<>();
        }
        return coll.stream().map(mapper).filter(Objects::nonNull).collect(Collectors.toList());
    }

    /**
     * 集合转去重数组
     *
     * @param coll   集合
     * @param mapper T-R转换器
     * @param <T>    输入泛型
     * @param <R>    输出泛型
     * @return List(R)
     */
    public static <T, R> List<R> toDistinctList(Collection<T> coll, Function<? super T, ? extends R> mapper) {
        if (isEmpty(coll)) {
            return new ArrayList<>();
        }
        return coll.stream().map(mapper).filter(Objects::nonNull).distinct().collect(Collectors.toList());
    }

    /**
     * 集合转map
     *
     * @param coll      集合
     * @param keyMapper T-K转换器
     * @param <T>       输入泛型，输出的map value泛型
     * @param <K>       输出的map key泛型
     * @return Map(K, T)
     */
    public static <T, K> Map<K, T> toMap(Collection<T> coll, Function<? super T, ? extends K> keyMapper) {
        return toMap(coll, keyMapper, t -> t);
    }

    /**
     * 集合转map
     *
     * @param coll        集合
     * @param keyMapper   T-K转换器
     * @param valueMapper T-U转换器
     * @param <T>         输入泛型
     * @param <K>         输出的 map key 泛型
     * @param <U>         输出的 map value 泛型
     * @return Map(K, U)
     */
    public static <T, K, U> Map<K, U> toMap(Collection<T> coll, Function<? super T, ? extends K> keyMapper, Function<T, U> valueMapper) {
        return toMap(coll, keyMapper, valueMapper, (a, b) -> b);
    }

    /**
     * 集合转map
     *
     * @param coll          集合
     * @param keyMapper     T-K转换器
     * @param valueMapper   T-U转换器
     * @param mergeFunction 碰到重复的key时，选择存储的value函数 (old, new) - ?
     * @param <T>           输入泛型
     * @param <K>           输出的 map key 泛型
     * @param <U>           输出的 map value 泛型
     * @return Map(K, U)
     */
    public static <T, K, U> Map<K, U> toMap(Collection<T> coll, Function<? super T, ? extends K> keyMapper, Function<? super T, ? extends U> valueMapper,
        BinaryOperator<U> mergeFunction) {
        if (isEmpty(coll)) {
            return new HashMap<>();
        }
        return coll.stream().collect(Collectors.toMap(keyMapper, valueMapper, mergeFunction));
    }

}
