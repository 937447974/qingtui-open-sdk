package com.qingtui.open.base.model.constant;


/**
 * 异常常量
 *
 * @author shizhen
 */
public class ExceptionConstants {

    public static final int SYSTEM_ERROR_CODE = -1;
    public static final int SUCCESS_CODE = 0;
    public static final String SYSTEM_ERROR_MESSAGE = "系统异常";

}