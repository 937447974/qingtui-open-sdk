package com.qingtui.open.im.channel.service;

import com.alibaba.fastjson.TypeReference;
import com.qingtui.open.base.http.HttpClient;
import com.qingtui.open.base.service.BaseService;
import com.qingtui.open.im.channel.model.bo.ChannelBO;
import com.qingtui.open.im.channel.model.bo.ChannelIdBO;
import com.qingtui.open.im.channel.model.param.ChannelCreateParam;
import com.qingtui.open.im.channel.model.param.ChannelUpdateParam;
import lombok.val;

import static com.qingtui.open.im.channel.model.constant.UrlConstants.CHAT_CHANNEL;

/**
 * <p> title: 群服务
 * <p> time: 2025/4/7 16:01
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public interface ChannelService {

    /**
     * 增加群
     *
     * @return 群id
     */
    String createChannel(ChannelCreateParam param);

    /**
     * 更新群聊会话
     */
    void updateChannel(ChannelUpdateParam param);

    /**
     * 获取群聊
     */
    ChannelBO getChannel(String channelId);

}