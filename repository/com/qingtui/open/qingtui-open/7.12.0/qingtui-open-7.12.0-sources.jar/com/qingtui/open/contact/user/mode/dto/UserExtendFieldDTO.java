package com.qingtui.open.contact.user.mode.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p> title: 成员扩展字段
 * <p> time: 2024/2/21 09:50
 * <p> Copyright © 2010-2024 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Accessors(chain = true)
@Data
@EqualsAndHashCode
@NoArgsConstructor
@ToString
public class UserExtendFieldDTO implements Serializable {

    /**
     * 扩展字段编码
     */
    String fieldCode;

    /**
     * 扩展字段值
     */
    Object fieldValue;
}
