package com.qingtui.open.base.model.bo;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * 基础列表返回信息
 *
 * @author shizhen
 */
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ListBO<T> implements Serializable {

    /**
     * 返回信息列表
     */
    List<T> list;

}