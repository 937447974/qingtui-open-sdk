package com.qingtui.open.subscription.service;

import com.qingtui.open.subscription.model.vo.SubscriptionArticleInfo;

import java.util.List;

/**
 * <p> title: 订阅号服务
 * <p> time: 2023/10/25 10:31
 * <p> Copyright © 2010-2023 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public interface SubscriptionService {

    /**
     * 获取发送的文章列表
     *
     * @param gmtSync 同步时间
     * @param size    请求数目
     * @return List(MessageArticleVO ）
     */
    List<SubscriptionArticleInfo> listArticle(Long gmtSync, Integer size);

}
