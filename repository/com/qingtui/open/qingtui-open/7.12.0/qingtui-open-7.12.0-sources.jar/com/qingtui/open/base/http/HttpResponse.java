package com.qingtui.open.base.http;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.qingtui.open.base.model.exception.SdkException;
import com.qingtui.open.base.model.bo.ListBO;
import com.qingtui.open.base.model.vo.BaseVO;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import lombok.val;

/**
 * <p> title:
 * <p> time: 2022/3/2 3:53 PM
 * <p> Copyright © 2010-2022 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Slf4j
@Data
public class HttpResponse {

    /**
     * 返回的数据
     */
    BaseVO baseVO;

    public HttpResponse(JSONObject jsonObject) {
        this.baseVO = new BaseVO();
        if (jsonObject == null) {
            baseVO.setCode(0);
            return;
        } else if (jsonObject.containsKey("code")) {
            baseVO.setCode(jsonObject.getInteger("code"));
            baseVO.setMessage(jsonObject.getString("message"));
        } else if (jsonObject.containsKey("errcode")) {
            baseVO.setCode(jsonObject.getInteger("errcode"));
            baseVO.setMessage(jsonObject.getString("errmsg"));
        } else {
            baseVO.setCode(0);
        }
        if (baseVO.getCode() != 0 && baseVO.getCode() != 200) {
            throw new SdkException(baseVO);
        }
        if (jsonObject.containsKey("data")) {
            try {
                baseVO.setData(jsonObject.getJSONObject("data"));
            } catch (Exception e) {
                baseVO.setData(jsonObject);
            }
        } else {
            baseVO.setData(jsonObject);
        }
    }

    /**
     * 获取data数据
     *
     * @param type TypeReference
     * @param <T>  TypeReference
     * @return T
     */
    public <T> T data(TypeReference<T> type) {
        if (baseVO.getData() == null || type == null) {
            return null;
        }
        val data = JSONObject.parseObject(baseVO.getData().toString(), type);
        log.debug(data.toString());
        return data;
    }

    /**
     * 获取data中的数组数据
     *
     * @param type TypeReference
     * @param <T>  TypeReference
     * @return List
     */
    public <T> List<T> list(TypeReference<ListBO<T>> type) {
        val data = data(type);
        return data == null ? new ArrayList<>() : data.getList();
    }

}
