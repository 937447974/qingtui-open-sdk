package com.qingtui.open.subscription.service.impl;

import com.alibaba.fastjson.TypeReference;
import com.qingtui.open.base.http.HttpClient;
import com.qingtui.open.base.model.bo.ListBO;
import com.qingtui.open.base.service.BaseService;
import com.qingtui.open.subscription.model.vo.SubscriptionArticleInfo;
import com.qingtui.open.subscription.service.SubscriptionService;
import com.qingtui.open.token.service.TokenService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.qingtui.open.subscription.model.constant.UrlConstant.ARTICLE_LIST;

/**
 * <p> title: 订阅号服务
 * <p> time: 2023/10/25 10:31
 * <p> Copyright © 2010-2023 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public class SubscriptionServiceImpl extends BaseService implements SubscriptionService {

    public SubscriptionServiceImpl(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    /**
     * 获取发送的文章列表
     *
     * @param gmtSync 同步时间
     * @param size    请求数目
     * @return List(MessageArticleVO ）
     */
    @Override
    public List<SubscriptionArticleInfo> listArticle(Long gmtSync, Integer size) {
        Map<String, Object> map = new HashMap<>();
        map.put("gmtSync", gmtSync);
        map.put("size", size);
        return HttpClient.getRequest(getBaseUrl(ARTICLE_LIST), map).list(new TypeReference<ListBO<SubscriptionArticleInfo>>() {
        });
    }

}
