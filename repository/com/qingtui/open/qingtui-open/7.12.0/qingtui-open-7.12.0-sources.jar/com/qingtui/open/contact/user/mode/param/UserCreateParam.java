package com.qingtui.open.contact.user.mode.param;

import com.qingtui.open.contact.user.mode.dto.UserExtendFieldDTO;
import com.qingtui.open.contact.user.mode.dto.UserOrganizationDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * <p> title: 增加成员
 * <p> time: 2025/3/11 15:53
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Accessors(chain = true)
@Data
@EqualsAndHashCode
@NoArgsConstructor
@ToString
public class UserCreateParam implements Serializable {
    /**
     * +86 国家编码
     */
    @NotNull
    String countryCode;
    /**
     * 电话
     */
    @NotNull
    String mobile;
    /**
     * 姓名
     */
    @NotNull
    String name;
    /**
     * 邮箱
     */
    String email;
    /**
     * 工号
     */
    String jobNumber;
    /**
     * 个人描述
     */
    String comment;
    /**
     * 组织机构list
     */
    List<UserOrganizationDTO> organizationList;
    /**
     * 用户扩展字段
     */
    List<UserExtendFieldDTO> extendFieldList;

}
