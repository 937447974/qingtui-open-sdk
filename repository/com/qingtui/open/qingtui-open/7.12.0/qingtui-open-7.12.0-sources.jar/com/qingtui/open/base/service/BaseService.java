package com.qingtui.open.base.service;

import com.qingtui.open.token.service.TokenService;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

/**
 * <p> title:
 * <p> time: 2022/3/2 3:33 PM
 * <p> Copyright © 2010-2022 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ToString
@NoArgsConstructor
public class BaseService {

    /**
     * 请求token
     */
    protected TokenService tokenService;

    /**
     * 获取团队路径
     *
     * @param path 子路径
     * @return 全路径
     */
    public String getTeamUrl(String path) {
        return this.tokenService.getTeamUrl(path);
    }

    /**
     * 获取常规路径
     *
     * @param path 子路径
     * @return 全路径
     */
    public String getBaseUrl(String path) {
        return this.tokenService.getBaseUrl(path);
    }

}
