package com.cisdi.nudgeplus.sdk.utils;

import com.google.gson.Gson;

public class JsonUtils {

    private static Gson gson = new Gson();

    public static String beanToJson(Object obj) {
        return gson.toJson(obj);
    }

    public static <T> T jsonToBean(String json, Class<T> cls) {
        return gson.fromJson(json, cls);
    }
}
