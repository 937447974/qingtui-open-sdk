package com.cisdi.nudgeplus.sdk.utils;

import java.util.Iterator;
import java.util.List;

/**
 * 字符串工具类
 *
 * @author guoxiang
 * @date 2019/8/21 4:01 PM
 */
public class StringUtils {

    public static boolean isEmpty(Object str) {
        return str == null || "".equals(str);
    }

    public static String join(List<String> list, String regex) {
        StringBuilder stringBuilder = new StringBuilder();
        for(Iterator<String> iterator = list.iterator(); iterator.hasNext(); stringBuilder.append(iterator.next())) {
            if (stringBuilder.length() != 0) {
                stringBuilder.append(regex);
            }
        }
        return stringBuilder.toString();
    }

}