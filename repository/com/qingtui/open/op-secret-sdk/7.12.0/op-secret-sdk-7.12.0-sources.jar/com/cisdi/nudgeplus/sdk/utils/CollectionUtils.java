package com.cisdi.nudgeplus.sdk.utils;

import java.util.Collection;

/**
 * 集合工具类
 *
 * @author guoxiang
 * @date 2019/8/21 4:05 PM
 */
public class CollectionUtils {

    /**
     * 集合是否为null或空集合
     */
    public static boolean isEmpty(Collection<?> collection) {
        return collection == null || collection.isEmpty();
    }
}