package com.cisdi.nudgeplus.sdk.constants;

import com.cisdi.nudgeplus.sdk.utils.NudgePlusConfig;

public class TokenConstants {

    public static final String BASE_URL = NudgePlusConfig.getValue("baseURL");
    public final static String TOKEN = "/token";
}
