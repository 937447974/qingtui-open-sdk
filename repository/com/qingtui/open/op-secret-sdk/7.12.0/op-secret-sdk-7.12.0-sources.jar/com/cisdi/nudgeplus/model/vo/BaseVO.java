package com.cisdi.nudgeplus.model.vo;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

/**
 * <p> title: web层返回的包装对象
 * <p> time: 2021/4/1 10:03 上午
 *
 * @author 阳君
 * @version 1.0
 */
@Data
@ToString
@NoArgsConstructor
public class BaseVO implements Serializable {

    public static long DEFAULT_SUCCESS_CODE = 0L;
    public static long DEFAULT_ERROR_CODE = -1L;

    Long code;
    String message;
    JSONObject data;

}
