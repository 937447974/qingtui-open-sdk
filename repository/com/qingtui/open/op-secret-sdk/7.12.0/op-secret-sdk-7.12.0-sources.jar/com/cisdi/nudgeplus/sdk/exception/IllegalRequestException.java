package com.cisdi.nudgeplus.sdk.exception;

import com.cisdi.nudgeplus.model.vo.BaseVO;
import com.cisdi.nudgeplus.tmsbeans.beans.BaseResult;

public class IllegalRequestException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    private long code = -1;
    private BaseResult error;

    public IllegalRequestException(BaseVO vo) {
        super(vo.getMessage());
        this.code = vo.getCode();
    }

    public IllegalRequestException() {
        super("请求路径或参数错误");
    }

    public IllegalRequestException(String msg) {
        super(msg);
    }

    public IllegalRequestException(String msg, Throwable cause) {
        super(msg, cause);
    }

    public IllegalRequestException(BaseResult error) {
        super(error.toString());
        this.error = error;
    }

    public IllegalRequestException(BaseResult error, Throwable cause) {
        super(error.toString());
        this.error = error;
    }

    public BaseResult getError() {
        return this.error;
    }

}
