/**
 * 针对org.apache.commons.codec.binary.Base64， 需要导入架包commons-codec-1.9（或commons-codec-1.8等其他版本） 官方下载地址：http://commons.apache.org/proper/commons-codec/download_codec.cgi
 */
package com.cisdi.nudgeplus.sdk.utils;

import java.nio.charset.Charset;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;

/**
 * 该类提供对轻推消息的加密解密功能
 */
public class QTBizMsgCrypt {

    private final static int AES_KEY_LENGTH = 43;

    private static Charset CHARSET = Charset.forName("utf-8");
    private Base64 base64 = new Base64();
    private byte[] aesKey;
    private String token;

    /**
     * 构造函数
     *
     * @param token 开发者设置的token
     * @param encodingAesKey 开发者设置的秘钥
     * @throws AesException 执行失败，请查看该异常的错误码和具体的错误信息
     */
    public QTBizMsgCrypt(String token, String encodingAesKey) {
        if (StringUtils.isEmpty(encodingAesKey) || encodingAesKey.length() != AES_KEY_LENGTH) {
            try {
                throw new AesException(AesException.IllegalAesKey);
            } catch (AesException e) {
                e.printStackTrace();
            }
        }

        this.token = token;
        aesKey = Base64.decodeBase64(encodingAesKey + "=");
    }

    /**
     * 对明文进行加密.
     *
     * @param text 需要加密的明文
     * @return 加密后base64编码的字符串
     * @throws AesException aes加密失败
     */
    public String encrypt(String text) throws AesException {
        if (StringUtils.isEmpty(text)) {
            return "";
        }

        ByteGroup byteCollector = new ByteGroup();
        byte[] textBytes = text.getBytes(CHARSET);

        // randomStr + networkBytesOrder + text + receiveid
        byteCollector.addBytes(textBytes);

        // ... + pad: 使用自定义的填充方式对明文进行补位填充
        byte[] padBytes = PKCS7Encoder.encode(byteCollector.size());
        byteCollector.addBytes(padBytes);

        // 获得最终的字节流, 未加密
        byte[] unencrypted = byteCollector.toBytes();

        try {
            // 设置加密模式为AES的CBC模式
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            SecretKeySpec keySpec = new SecretKeySpec(aesKey, "AES");
            IvParameterSpec iv = new IvParameterSpec(aesKey, 0, 16);
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, iv);

            // 加密
            byte[] encrypted = cipher.doFinal(unencrypted);

            // 使用BASE64对加密后的字符串进行编码
            String base64Encrypted = base64.encodeToString(encrypted);

            return base64Encrypted;
        } catch (Exception e) {
            e.printStackTrace();
            throw new AesException(AesException.EncryptAESError);
        }
    }

    /**
     * 对密文进行解密.
     *
     * @param text 需要解密的密文
     * @return 解密得到的明文
     * @throws AesException aes解密失败
     */
    public String decrypt(String text) throws AesException {
        if (StringUtils.isEmpty(text)) {
            return "";
        }

        byte[] original;
        try {
            // 设置解密模式为AES的CBC模式
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            SecretKeySpec key_spec = new SecretKeySpec(aesKey, "AES");
            IvParameterSpec iv = new IvParameterSpec(Arrays.copyOfRange(aesKey, 0, 16));
            cipher.init(Cipher.DECRYPT_MODE, key_spec, iv);

            // 使用BASE64对密文进行解码
            byte[] encrypted = Base64.decodeBase64(text);

            // 解密
            original = cipher.doFinal(encrypted);
        } catch (Exception e) {
            e.printStackTrace();
            throw new AesException(AesException.DecryptAESError);
        }

        return new String(original).trim();
    }
}