package com.cisdi.nudgeplus.model.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * <p> title: 数组输出
 * <p> time: 2021/4/1 10:03 上午
 *
 * @author 阳君
 * @version 1.0
 */
@Data
@ToString
@NoArgsConstructor
public class ListVO<T> implements Serializable {

    List<T> list;

    public static <T> List<T> getData(ListVO<T> data) {
        return data != null ? data.getList() : new ArrayList<>();
    }
}
