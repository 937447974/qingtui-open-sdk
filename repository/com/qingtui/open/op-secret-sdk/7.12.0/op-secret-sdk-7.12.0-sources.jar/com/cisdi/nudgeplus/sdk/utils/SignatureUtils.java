package com.cisdi.nudgeplus.sdk.utils;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.List;

/**
 * 签名工具类
 *
 * @author guoxiang
 * @date 2019/8/16 3:02 PM
 */
public class SignatureUtils {

    /**
     * @param signatureSecret 签名密钥
     * @param object 参数对象
     */
    public static String signature(String signatureSecret, Object object) {
        List<Object> params = new ArrayList<>();

        JSONObject jsonObject = (JSONObject) JSONObject.toJSON(object);
        if (jsonObject != null) {
            params.addAll(jsonObject.values());
        }

        return SignatureUtils.signature(signatureSecret, params);
    }

    /**
     * @param signatureSecret 签名密钥
     * @param params 参数列表
     */
    public static String signature(String signatureSecret, List<Object> params) {
        if ((StringUtils.isEmpty(signatureSecret))) {
            throw new AesException(AesException.EMPTY_SIGNATURE_SECRET);
        }
        if (CollectionUtils.isEmpty(params)) {
            return "";
        }

        Gson gson = new Gson();

        params.add(signatureSecret);
        String[] array = new String[params.size()];
        for (int i = 0; i < params.size(); i++) {
            array[i] = gson.toJson(params.get(i));
        }

        return SHA1.getSHA1(array);
    }
}