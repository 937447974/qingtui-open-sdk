package com.cisdi.nudgeplus.tmsbeans.beans.member;

import com.cisdi.nudgeplus.tmsbeans.beans.BaseResult;
import java.util.List;

/**
 * 开放平台信息
 *
 * @author shizhen
 */
public class OpenInfo extends BaseResult {

    private List<FollowerInfo> followerInfo;

    public List<FollowerInfo> getFollowerInfo() {
        return followerInfo;
    }

    public void setFollowerInfo(List<FollowerInfo> followerInfo) {
        this.followerInfo = followerInfo;
    }
}