package com.cisdi.nudgeplus.sdk.service.tobusiness;

import com.cisdi.nudgeplus.sdk.constants.PathConstants;
import com.cisdi.nudgeplus.sdk.datamng.ClientUtils;
import com.cisdi.nudgeplus.sdk.exception.IllegalMessageException;
import com.cisdi.nudgeplus.sdk.exception.IllegalRequestException;
import com.cisdi.nudgeplus.sdk.utils.JsonUtils;
import com.cisdi.nudgeplus.tmsbeans.beans.MessageResult;
import com.cisdi.nudgeplus.tmsbeans.beans.ResultWapper;
import com.cisdi.nudgeplus.tmsbeans.model.RichMsg;
import com.cisdi.nudgeplus.tmsbeans.model.request.basics.ServiceSendRequest;

/**
 * @author liyu
 */
public class SendServiceMsg {

    public static String sendRichServiceMsg(RichMsg richMsg, String appId, String domainId, String accessToken) {
        if (richMsg == null) {
            throw new IllegalMessageException();
        }

        ResultWapper<MessageResult> resultWapper = ClientUtils.post(
//            PathConstants.BASE_URL + PathConstants.TB_RICH_SERVICE_PATH,
            "http://localhost:8181/v1"+ PathConstants.TB_RICH_SERVICE_PATH,
            accessToken,
            JsonUtils.beanToJson(buildRichServiceMsg(richMsg, appId, domainId)),
            MessageResult.class);

        if (resultWapper.isError()) {
            throw new IllegalRequestException(resultWapper.getErrorResult());
        }
        return resultWapper.getResult().getMsgId();
    }

    private static ServiceSendRequest<RichMsg> buildRichServiceMsg(RichMsg richMsg, String appId, String domainId) {
        ServiceSendRequest<RichMsg> richMsgServiceSendRequest = new ServiceSendRequest<>();
        richMsgServiceSendRequest.setMessage(richMsg);
        richMsgServiceSendRequest.setAppId(appId);
        richMsgServiceSendRequest.setSendDomainId(domainId);
        return richMsgServiceSendRequest;
    }
}