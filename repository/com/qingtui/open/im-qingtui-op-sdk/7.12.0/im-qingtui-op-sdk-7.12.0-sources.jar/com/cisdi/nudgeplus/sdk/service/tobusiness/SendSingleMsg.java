package com.cisdi.nudgeplus.sdk.service.tobusiness;

import com.cisdi.nudgeplus.sdk.constants.PathConstants;
import com.cisdi.nudgeplus.sdk.datamng.ClientUtils;
import com.cisdi.nudgeplus.sdk.exception.IllegalMessageException;
import com.cisdi.nudgeplus.sdk.exception.IllegalRequestException;
import com.cisdi.nudgeplus.sdk.utils.JsonUtils;
import com.cisdi.nudgeplus.tmsbeans.beans.MessageResult;
import com.cisdi.nudgeplus.tmsbeans.beans.ResultWapper;
import com.cisdi.nudgeplus.tmsbeans.model.RichMsg;
import com.cisdi.nudgeplus.tmsbeans.model.request.basics.SingleSendRequest;
import com.cisdi.nudgeplus.tmsbeans.model.request.media.MediaMsg;

/**
 * @author liyu
 */
public class SendSingleMsg {

    /**
     * Q8单发富文本消息
     *
     * @param toUser openId
     * @param richMsg 富文本消息体
     * @param appId Q8轻应用 appId
     * @param accessToken token
     * @return msgId
     */
    public static String sendSingleRichMsg(String toUser, RichMsg richMsg, String appId, String accessToken) {
        if (richMsg == null) {
            throw new IllegalMessageException();
        }

        ResultWapper<MessageResult> resultWapper = ClientUtils.post(
            PathConstants.BASE_URL + PathConstants.TB_RICH_SINGLE_PATH,
            accessToken,
            JsonUtils.beanToJson(buildSingleRichMsg(toUser, appId, richMsg)),
            MessageResult.class);

        if (resultWapper.isError()) {
            throw new IllegalRequestException(resultWapper.getErrorResult());
        }
        return resultWapper.getResult().getMsgId();
    }

    private static SingleSendRequest<RichMsg> buildSingleRichMsg(String toUser, String appId, RichMsg richMsg) {
        SingleSendRequest<RichMsg> singleSendRequest = new SingleSendRequest<>();
        singleSendRequest.setTo_user(toUser);
        singleSendRequest.setAppId(appId);
        singleSendRequest.setMessage(richMsg);
        return singleSendRequest;
    }

    /**
     * Q8单发文件消息
     *
     * @param toUser openId
     * @param mediaMsg 文件消息体
     * @param appId Q8轻应用 appId
     * @param accessToken accessToken
     * @return msgId
     */
    public static String sendSingleFileMsg(String toUser, MediaMsg mediaMsg, String appId, String accessToken) {
        if (mediaMsg == null) {
            throw new IllegalMessageException();
        }

        ResultWapper<MessageResult> resultWapper = ClientUtils.post(
            PathConstants.BASE_URL + PathConstants.TB_FILE_SINGLE_PATH,
            accessToken,
            JsonUtils.beanToJson(buildSingleFileMsg(toUser, appId, mediaMsg)),
            MessageResult.class);

        if (resultWapper.isError()) {
            throw new IllegalRequestException(resultWapper.getErrorResult());
        }
        return resultWapper.getResult().getMsgId();
    }

    private static SingleSendRequest<MediaMsg> buildSingleFileMsg(String toUser, String appId, MediaMsg mediaMsg) {
        SingleSendRequest<MediaMsg> singleSendRequest = new SingleSendRequest<>();
        singleSendRequest.setTo_user(toUser);
        singleSendRequest.setMessage(mediaMsg);
        singleSendRequest.setAppId(appId);
        return singleSendRequest;
    }
}