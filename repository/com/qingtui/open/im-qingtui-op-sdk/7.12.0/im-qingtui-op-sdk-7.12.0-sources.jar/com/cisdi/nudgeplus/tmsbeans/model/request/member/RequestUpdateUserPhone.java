package com.cisdi.nudgeplus.tmsbeans.model.request.member;

import java.io.Serializable;

/**
 * 修改手机号码请求参数
 *
 * @author shizhen
 */
public class RequestUpdateUserPhone implements Serializable {

    /**
     * 轻推帐号id
     */
    private String accountId;
    /**
     * 国际号
     */
    private String countryCode;
    /**
     * 电话号码
     */
    private String mobilePhone;
    /**
     * 验证码
     */
    private String authCode;

    public String getAccountId() {
        return accountId;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public String getAuthCode() {
        return authCode;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }
}