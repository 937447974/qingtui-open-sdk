package com.cisdi.nudgeplus.tmsbeans.model.request.member;

import java.util.ArrayList;
import java.util.List;

import com.cisdi.nudgeplus.tmsbeans.beans.member.UserExtendField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * 更新用户请求参数实体
 *
 * @author shizhen
 */
@ToString(callSuper = true)
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class RequestUpdateUser extends RequestUser {

    private String name;//姓名
    private String orgId;//组织机构id
    private List<String> orgList;//组织机构list
    private String comment;//详情
    private String employeeId;//工号
    private String email;//邮箱
    /**
     * 主组织机构id
     */
    String masterOrgId;
    /**
     * 用户扩展字段
     */
    List<UserExtendField> extendFieldList = new ArrayList<>();

}