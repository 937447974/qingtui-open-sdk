package com.cisdi.nudgeplus.sdk.service.tobusiness;

import com.cisdi.nudgeplus.sdk.constants.PathConstants;
import com.cisdi.nudgeplus.sdk.datamng.ClientUtils;
import com.cisdi.nudgeplus.sdk.exception.IllegalMessageException;
import com.cisdi.nudgeplus.sdk.exception.IllegalRequestException;
import com.cisdi.nudgeplus.sdk.utils.JsonUtils;
import com.cisdi.nudgeplus.tmsbeans.beans.MessageResult;
import com.cisdi.nudgeplus.tmsbeans.beans.ResultWapper;
import com.cisdi.nudgeplus.tmsbeans.model.RichMsg;
import com.cisdi.nudgeplus.tmsbeans.model.request.basics.MassSendRequest;
import com.cisdi.nudgeplus.tmsbeans.model.request.media.MediaMsg;
import java.util.List;

/**
 * @author liyu
 */
public class SendMassMsg {

    /**
     * Q8批量发富文本消息
     *
     * @param toUsers openIds
     * @param richMsg 富文本消息体
     * @param appId appId
     * @param accessToken accessToken
     * @return msgId
     */
    public static String sendMassRichMsg(List<String> toUsers, RichMsg richMsg, String appId, String accessToken) {
        if (richMsg == null) {
            throw new IllegalMessageException();
        }

        ResultWapper<MessageResult> resultWapper = ClientUtils.post(
            PathConstants.BASE_URL + PathConstants.TB_RICH_MASS_PATH,
            accessToken,
            JsonUtils.beanToJson(buildMassRichMsg(toUsers, richMsg, appId)),
            MessageResult.class);

        if (resultWapper.isError()) {
            throw new IllegalRequestException(resultWapper.getErrorResult());
        }
        return resultWapper.getResult().getMsgId();
    }

    private static MassSendRequest<RichMsg> buildMassRichMsg(List<String> toUser, RichMsg richMsg, String appId) {
        MassSendRequest<RichMsg> msgMassSendRequest = new MassSendRequest<>();
        msgMassSendRequest.setTo_users(toUser);
        msgMassSendRequest.setAppId(appId);
        msgMassSendRequest.setMessage(richMsg);
        return msgMassSendRequest;
    }

    /**
     * Q8批量发文件消息
     *
     * @param toUsers openIds
     * @param mediaMsg 文件消息体
     * @param appId appId
     * @param accessToken accessToken
     * @return msgId
     */
    public static String sendMassFileMsg(List<String> toUsers, MediaMsg mediaMsg, String appId, String accessToken) {
        if (mediaMsg == null) {
            throw new IllegalMessageException();
        }

        ResultWapper<MessageResult> resultWapper = ClientUtils.post(
            PathConstants.BASE_URL + PathConstants.TB_FILE_MASS_PATH,
            accessToken,
            JsonUtils.beanToJson(buildMassFileMsg(toUsers, mediaMsg, appId)),
            MessageResult.class);

        if (resultWapper.isError()) {
            throw new IllegalRequestException(resultWapper.getErrorResult());
        }
        return resultWapper.getResult().getMsgId();
    }

    private static MassSendRequest<MediaMsg> buildMassFileMsg(List<String> toUser, MediaMsg mediaMsg, String appId) {
        MassSendRequest<MediaMsg> msgMassSendRequest = new MassSendRequest<>();
        msgMassSendRequest.setTo_users(toUser);
        msgMassSendRequest.setAppId(appId);
        msgMassSendRequest.setMessage(mediaMsg);
        return msgMassSendRequest;
    }
}