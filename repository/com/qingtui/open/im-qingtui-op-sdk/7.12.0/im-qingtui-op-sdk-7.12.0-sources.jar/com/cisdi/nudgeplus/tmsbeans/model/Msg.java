package com.cisdi.nudgeplus.tmsbeans.model;

public class Msg  extends MsgModel{

	private String touser;

	private String appId;

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getTouser() {
		return touser;
	}

	public void setTouser(String touser) {
		this.touser = touser;
	}

}
