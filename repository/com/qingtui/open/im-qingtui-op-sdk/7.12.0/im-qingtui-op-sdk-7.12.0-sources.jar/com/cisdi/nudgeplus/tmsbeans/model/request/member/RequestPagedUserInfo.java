package com.cisdi.nudgeplus.tmsbeans.model.request.member;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * 分页获取用户信息请求参数实体
 *
 * @author shizhen
 */
@EqualsAndHashCode
@Data
@ToString
@NoArgsConstructor
public class RequestPagedUserInfo implements Serializable {

    private int pageSize = 1;//每页大小
    private int requestPage;//请求页数
    private String domainId;//团队id
    /**
     * 是否需要组织机构列表
     */
    private boolean needOrganizationList = false;
}