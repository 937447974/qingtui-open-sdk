package com.cisdi.nudgeplus.tmsbeans.model.request.basics;

import java.io.Serializable;

/**
 * 服务号群发请求
 *
 * @author shizhen
 */
public class ServiceSendRequest<T extends Message> implements Serializable {

    private T message;

    private String appId;

    private String sendDomainId;

    public T getMessage() {
        return message;
    }

    public void setMessage(T message) {
        this.message = message;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getSendDomainId() {
        return sendDomainId;
    }

    public void setSendDomainId(String sendDomainId) {
        this.sendDomainId = sendDomainId;
    }
}