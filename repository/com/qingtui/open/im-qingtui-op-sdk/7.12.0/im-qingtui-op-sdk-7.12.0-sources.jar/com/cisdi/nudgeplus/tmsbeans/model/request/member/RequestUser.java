package com.cisdi.nudgeplus.tmsbeans.model.request.member;

import java.io.Serializable;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * 请求用户参数实体类
 *
 * @author shizhen
 */
@Data
@ToString
@NoArgsConstructor
public class RequestUser implements Serializable {

    private String domainId;//团队id
    private String accountId;//用户aid

}