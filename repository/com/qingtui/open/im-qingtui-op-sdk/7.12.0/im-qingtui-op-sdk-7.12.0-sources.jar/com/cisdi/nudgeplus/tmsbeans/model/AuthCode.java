package com.cisdi.nudgeplus.tmsbeans.model;

import com.cisdi.nudgeplus.tmsbeans.beans.BaseResult;

/**
 * 验证码
 *
 * @author shizhen
 */
public class AuthCode extends BaseResult {

    private int cooldown;

    public int getCooldown() {
        return cooldown;
    }

    public void setCooldown(int cooldown) {
        this.cooldown = cooldown;
    }
}