package com.cisdi.nudgeplus.tmsbeans.model;

import com.cisdi.nudgeplus.tmsbeans.beans.BaseResult;

/**
 * 用户信息实体类
 *
 * @author shizhen
 */
public class User extends BaseResult {

    private static final long serialVersionUID = 1L;
    private String account_id;
    private String user_id;


    public String getAccountId() {
        return account_id;
    }

    public void setAccountId(String accountId) {
        this.account_id = accountId;
    }

    public String getUserId() {
        return user_id;
    }

    public void setUserIdd(String userId) {
        this.user_id = userId;
    }
}