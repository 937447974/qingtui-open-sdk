package com.cisdi.nudgeplus.tmsbeans.beans.member;

import com.cisdi.nudgeplus.tmsbeans.beans.BaseResult;
import com.google.gson.annotations.SerializedName;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 用户详情实体类
 *
 * @author shizhen
 */
@Data
@NoArgsConstructor
public class UserDetail extends BaseResult {

    private static final long serialVersionUID = 1L;

    @SerializedName("user_id")
    private String userId;//userId
    /**
     * 关注者id
     */
    @SerializedName("open_id")
    private String openId;
    private String name;//姓名
    private String mobile;//电话号码
    private String mail;//邮箱
    private String avatar;//头像
    private String comment;//描述
    @SerializedName("account_id")
    private String accountId;//accountId
    @SerializedName("org_list")
    private List<String> orgList;//组织机构list
    /**
     * 主组织机构id
     */
    @Deprecated
    @SerializedName("master_org_id")
    String masterOrgId;
    @Deprecated
    @SerializedName("org_id")
    private String orgId;//组织机构id
    private String guest;//访客
    @SerializedName("employee_id")
    private String employeeId;//工号

    
}