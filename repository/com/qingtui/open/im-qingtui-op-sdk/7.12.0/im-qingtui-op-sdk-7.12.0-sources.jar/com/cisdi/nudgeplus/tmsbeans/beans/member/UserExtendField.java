package com.cisdi.nudgeplus.tmsbeans.beans.member;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * <p> title: 用户扩展字段
 * <p> time: 2024/2/19 17:37
 * <p> Copyright © 2010-2024 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ToString
@EqualsAndHashCode
@NoArgsConstructor
public class UserExtendField implements Serializable {

    /**
     * 扩展字段编码
     */
    String fieldCode;

    /**
     * 扩展字段值
     */
    Object fieldValue;
}
