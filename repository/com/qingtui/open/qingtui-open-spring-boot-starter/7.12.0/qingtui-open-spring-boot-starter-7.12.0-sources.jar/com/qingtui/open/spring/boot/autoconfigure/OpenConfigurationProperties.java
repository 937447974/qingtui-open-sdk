package com.qingtui.open.spring.boot.autoconfigure;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * <p> title:
 * <p> time: 2025/4/15 14:04
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Data
@ConfigurationProperties(prefix = "qingtui.open")
public class OpenConfigurationProperties {
    /**
     * 应用id
     */
    String appId;
    /**
     * 应用密钥
     */
    String appSecret;
    /**
     * 开放平台地址
     */
    String url = "https://open.qingtui.com";

}
