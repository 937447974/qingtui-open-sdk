package com.qingtui.open.spring.scheduling;

import com.qingtui.open.token.service.TokenService;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * <p> title: 开放平台调度器
 * <p> time: 2025/5/9 08:56
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
public class OpenScheduler {

    private static final long MILLIS_PER_MINUTE = 60000L;

    TokenService tokenService;

    public OpenScheduler(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    /**
     * token 2个小时有效期，40分钟刷新一次，一个周期刷新3次
     */
    @Scheduled(initialDelay = 40 * MILLIS_PER_MINUTE, fixedDelay = 40 * MILLIS_PER_MINUTE)
    public void refreshToken() {
        this.tokenService.refreshToken();
    }

}
