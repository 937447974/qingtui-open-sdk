package com.qingtui.open.spring.boot.autoconfigure;

import com.qingtui.open.attendance.service.AttendanceService;
import com.qingtui.open.attendance.service.impl.AttendanceServiceImpl;
import com.qingtui.open.contact.org.service.OrgService;
import com.qingtui.open.contact.org.service.impl.OrgServiceImpl;
import com.qingtui.open.contact.user.service.UserService;
import com.qingtui.open.contact.user.service.impl.UserServiceImpl;
import com.qingtui.open.im.channel.service.ChannelService;
import com.qingtui.open.im.channel.service.impl.ChannelServiceImpl;
import com.qingtui.open.im.message.service.MessageService;
import com.qingtui.open.im.message.service.impl.MessageServiceImpl;
import com.qingtui.open.schedule.service.ScheduleService;
import com.qingtui.open.schedule.service.impl.ScheduleServiceImpl;
import com.qingtui.open.spring.scheduling.OpenScheduler;
import com.qingtui.open.subscription.service.SubscriptionService;
import com.qingtui.open.subscription.service.impl.SubscriptionServiceImpl;
import com.qingtui.open.token.service.TokenService;
import com.qingtui.open.token.service.impl.TokenServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * <p> title:
 * <p> time: 2025/4/15 14:02
 * <p> Copyright © 2025-至今 CISDI Info. All Rights Reserved.
 *
 * @author 阳君
 * @version 1.0.0
 */
@Slf4j
@ConditionalOnProperty(prefix = "qingtui.open", name = {"enabled"}, matchIfMissing = true)
@Configuration
@EnableScheduling
@EnableConfigurationProperties(OpenConfigurationProperties.class)
public class OpenAutoConfiguration implements InitializingBean {

    OpenConfigurationProperties properties;

    public OpenAutoConfiguration(OpenConfigurationProperties properties) {
        this.properties = properties;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
    }
    @Bean
    public TokenService openTokenService() {
        return new TokenServiceImpl(this.properties.getAppId(), this.properties.getAppSecret(), this.properties.getUrl());
    }

    @Bean
    @ConditionalOnMissingBean
    public OpenScheduler openScheduler(TokenService tokenService) {
        return new OpenScheduler(tokenService);
    }

    @Bean
    @ConditionalOnMissingBean
    public UserService openUserService(TokenService tokenService) {
        return new UserServiceImpl(tokenService);
    }

    @Bean
    @ConditionalOnMissingBean
    public OrgService openOrgService(TokenService tokenService) {
        return new OrgServiceImpl(tokenService);
    }

    @Bean
    @ConditionalOnMissingBean
    public ScheduleService openScheduleService(TokenService tokenService) {
        return new ScheduleServiceImpl(tokenService);
    }

    @Bean
    @ConditionalOnMissingBean
    public SubscriptionService openSubscriptionService(TokenService tokenService) {
        return new SubscriptionServiceImpl(tokenService);
    }

    @Bean
    @ConditionalOnMissingBean
    public ChannelService openChannelService(TokenService tokenService) {
        return new ChannelServiceImpl(tokenService);
    }

    @Bean
    @ConditionalOnMissingBean
    public MessageService openMessageService(TokenService tokenService) {
        return new MessageServiceImpl(tokenService);
    }

    @Bean
    @ConditionalOnMissingBean
    public AttendanceService openAttendanceService(TokenService tokenService) {
        return new AttendanceServiceImpl(tokenService);
    }

}
